#!/usr/bin/python3 -I
"""Unprivileged single-ID sandbox. systemd user units enforce each job's limits."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import tempfile
import time

RUNTIME_BASE = Path('/var/lib/addon-manager-runner/runtimes')
LAUNCHER = '/usr/local/libexec/addon-manager-bubblewrap.py'
UNIT_PATTERN = re.compile(r'^addon-manager-stage-[0-9a-f]{20}\.service$')
APP_ENVIRONMENT = {
    'PATH': '/usr/bin:/bin:/usr/local/bin', 'HOME': '/tmp/home', 'TMPDIR': '/tmp', 'LANG': 'C.UTF-8',
    'APP_ENV': 'testing', 'APP_DEBUG': 'false', 'APP_ENVIRONMENT_ONLY': 'true',
    'APP_KEY': 'base64:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
    'DB_CONNECTION': 'sqlite', 'DB_DATABASE': '/tmp/validation.sqlite',
    'CACHE_STORE': 'array', 'CACHE_DRIVER': 'array', 'SESSION_DRIVER': 'array',
    'QUEUE_CONNECTION': 'sync', 'LOG_CHANNEL': 'stderr',
}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def plain_path(value, directory=True):
    path = Path(value)
    require(path.is_absolute() and str(path) == str(path.resolve(strict=True)), 'Runner paths must be absolute without symlinks')
    require(path.is_dir() if directory else path.is_file(), 'Required runner path is missing')
    return path


def root_owned(path):
    current = path
    while True:
        info = current.lstat()
        require(not stat.S_ISLNK(info.st_mode) and info.st_uid == 0 and info.st_mode & 0o022 == 0,
                'Runtime and launcher paths must be root-owned and not writable by other users: ' + str(current))
        if current == Path('/'):
            break
        current = current.parent


def runtime_info(args, full=False):
    runtime = plain_path(args.runtime)
    require(runtime.parent == RUNTIME_BASE, 'Runtime is outside its approved directory')
    root_owned(runtime)
    manifest_file = runtime / 'runtime-manifest.json'
    root_owned(manifest_file)
    data = manifest_file.read_bytes()
    require(args.digest == 'sha256:' + hashlib.sha256(data).hexdigest(), 'Runtime manifest fingerprint changed')
    manifest = json.loads(data)
    require(manifest.get('version') == 1 and manifest.get('architecture') == 'x86_64', 'Unsupported runtime manifest')
    require(os.uname().machine == 'x86_64', 'This runtime targets x86_64')
    if full:
        for relative, expected in manifest['files'].items():
            parts = Path(relative).parts
            require(not Path(relative).is_absolute() and '..' not in parts, 'Unsafe runtime inventory path')
            path = runtime / relative
            root_owned(path)
            require(path.is_file() and hashlib.file_digest(path.open('rb'), 'sha256').hexdigest() == expected,
                    'Runtime file changed: ' + relative)
    root_owned(runtime / 'sandbox.bpf')
    return runtime, manifest


def user_environment():
    uid = os.geteuid()
    require(uid != 0, 'Run the manager and this launcher as the unprivileged Panel owner')
    runtime = Path(f'/run/user/{uid}')
    bus = runtime / 'bus'
    require(runtime.is_dir() and runtime.stat().st_uid == uid and bus.is_socket() and bus.stat().st_uid == uid,
            'The Panel owner needs its persistent systemd user manager')
    return {'PATH': '/usr/local/bin:/usr/bin:/bin', 'LANG': 'C.UTF-8',
            'XDG_RUNTIME_DIR': str(runtime), 'DBUS_SESSION_BUS_ADDRESS': 'unix:path=' + str(bus)}


def systemctl(*arguments, check=False):
    return subprocess.run(['/usr/bin/systemctl', '--user', *arguments], env=user_environment(),
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=check, timeout=15)


def unit_state(unit):
    result = systemctl('show', '--all', '--property=LoadState,ActiveState,ControlGroup,MainPID,ControlPID', '--', unit)
    return dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)


def stop_unit(unit):
    require(UNIT_PATTERN.fullmatch(unit) is not None, 'Invalid sandbox unit name')
    result = systemctl('stop', '--', unit)
    state = unit_state(unit)
    require(state.get('LoadState') == 'not-found'
            or (state.get('ActiveState') in ('inactive', 'failed')
                and state.get('MainPID', '0') == '0' and state.get('ControlPID', '0') == '0'),
            'Sandbox unit did not stop')


def limits(args):
    require(re.fullmatch(r'[1-9][0-9]*(?:m|g)', args.memory) is not None, 'Invalid sandbox memory limit')
    memory = int(args.memory[:-1]) * (1024 ** (2 if args.memory[-1] == 'm' else 3))
    require(64 * 1024 ** 2 <= memory <= 16 * 1024 ** 3, 'Sandbox memory must be between 64 MiB and 16 GiB')
    require(re.fullmatch(r'[1-9](?:\.[0-9])?', args.cpus) is not None, 'Invalid sandbox CPU limit')
    return memory, float(args.cpus)


def check_cgroup(unit, memory, cpus):
    state = unit_state(unit)
    group = state.get('ControlGroup', '')
    if not group or state.get('ActiveState') != 'active':
        return False
    require(group.startswith('/') and '..' not in Path(group).parts, 'Invalid job cgroup path')
    path = Path('/sys/fs/cgroup') / group.lstrip('/')
    require(int((path / 'memory.max').read_text().strip()) == memory, 'Memory controller did not enforce the requested limit')
    require(int((path / 'pids.max').read_text().strip()) == 128, 'PID controller did not enforce the requested limit')
    quota, period = (path / 'cpu.max').read_text().split()
    require(quota != 'max' and abs(int(quota) / int(period) - cpus) < 0.001,
            'CPU controller did not enforce the requested limit')
    swap = path / 'memory.swap.max'
    require(swap.is_file() and swap.read_text().strip() == '0', 'Swap limit was not enforced')
    require((path / 'memory.oom.group').read_text().strip() == '1', 'OOM handling is not scoped to the sandbox group')
    return True


def check_stage(args):
    panel, state = plain_path(args.panel), plain_path(args.state)
    require(state == panel / 'storage/app/addon-manager' and state.stat().st_uid == os.geteuid(), 'Unexpected private state directory')
    stage, job = plain_path(args.stage), plain_path(args.job)
    require(stage != state and stage.is_relative_to(state), 'Stage is outside private state')
    if args.profile not in ('doctor', 'doctor-node'):
        require(job.parent == state / 'runner-jobs' and re.fullmatch(r'[0-9a-f]{24}', job.name) is not None,
                'Unexpected private runner job directory')
        require((job / 'input.json').is_file() and not (job / 'input.json').is_symlink(), 'Runner job input is missing')
    else:
        require(job.is_relative_to(state / 'runner-probes'), 'Unexpected doctor job directory')
    for name in ('.env', '.git'):
        require(not (stage / name).exists() and not (stage / name).is_symlink(), 'Protected staged path: ' + name)
    for name in ('vendor', 'node_modules', 'addon-manager'):
        path = stage / name
        require(not path.exists() or (path.is_dir() and not path.is_symlink() and not any(path.iterdir())), 'Nonempty protected stage mount point')
    return panel, state, stage, job


def bubblewrap_command(args, runtime):
    panel, state, stage, job = check_stage(args)
    command = ['/usr/bin/bwrap', '--unshare-user', '--uid', '0', '--gid', '0',
               '--unshare-pid', '--unshare-net', '--unshare-ipc', '--unshare-uts',
               '--new-session', '--die-with-parent', '--cap-drop', 'ALL',
               '--ro-bind', str(runtime), '/', '--ro-bind', str(stage), '/work',
               '--ro-bind', str(job), '/job', '--proc', '/proc', '--dev', '/dev',
               '--size', str(128 * 1024 ** 2), '--tmpfs', '/tmp', '--dir', '/tmp/home',
               '--size', str(64 * 1024 ** 2), '--tmpfs', '/work/storage',
               '--size', str(16 * 1024 ** 2), '--tmpfs', '/work/bootstrap/cache',
               '--clearenv', '--chdir', '/work']
    environment = dict(APP_ENVIRONMENT)
    if args.profile in ('php', 'node'):
        manager = plain_path(str(panel / 'addon-manager'))
        source = plain_path(str(manager / 'src/Runner'))
        command += ['--ro-bind', str(source), '/runner']
    if args.profile == 'php':
        vendor = plain_path(str(panel / 'vendor'))
        require(vendor.is_relative_to(panel), 'Vendor directory escapes the Panel')
        command += ['--ro-bind', str(vendor), '/work/vendor', '--ro-bind', str(manager), '/work/addon-manager']
        program = ['/usr/bin/php', '/runner/probe.php']
    elif args.profile == 'node':
        modules = plain_path(str(panel / 'node_modules'))
        assets = plain_path(str(stage / 'public/assets'))
        require(modules.is_relative_to(panel) and assets.is_relative_to(stage), 'Build paths escape their approved roots')
        command += ['--ro-bind', str(modules), '/work/node_modules', '--ro-bind', str(assets), '/baseline-assets',
                    '--size', str(128 * 1024 ** 2), '--tmpfs', '/work/public/assets']
        memory, _ = limits(args)
        environment['NODE_OPTIONS'] = '--max-old-space-size=' + str(max(128, memory // (1024 ** 2) - 512))
        program = ['/usr/bin/node', '/runner/build.js']
    elif args.profile == 'doctor':
        program = ['/usr/bin/php', '/sandbox-selftest.php']
    else:
        program = ['/usr/bin/node', '/sandbox-selftest.js']
    for key, value in environment.items():
        command += ['--setenv', key, value]
    fd = os.open(runtime / 'sandbox.bpf', os.O_RDONLY)
    os.set_inheritable(fd, True)
    command += ['--seccomp', str(fd), '--', *program]
    return command


def inside(args):
    runtime, _ = runtime_info(args)
    require(sys.stdin.buffer.read(1) == b'1', 'Resource enforcement gate was not opened')
    command = bubblewrap_command(args, runtime)
    null = os.open('/dev/null', os.O_RDONLY)
    os.dup2(null, 0)
    os.close(null)
    os.execve(command[0], command, {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'})


def run_profile(args, capture=False):
    require(UNIT_PATTERN.fullmatch(args.unit) is not None, 'Invalid sandbox unit name')
    runtime_info(args)
    check_stage(args)
    memory, cpus = limits(args)
    affinity = sorted(os.sched_getaffinity(0))[:max(1, int(cpus + 0.999))]
    require(30 <= args.timeout <= 1800, 'Invalid sandbox timeout')
    nested = ['/usr/bin/python3', '-I', LAUNCHER, 'inside', '--profile', args.profile,
              '--unit', args.unit, '--runtime', args.runtime, '--digest', args.digest,
              '--panel', args.panel, '--state', args.state, '--stage', args.stage, '--job', args.job,
              '--memory', args.memory, '--cpus', args.cpus, '--timeout', str(args.timeout)]
    command = ['/usr/bin/systemd-run', '--user', '--quiet', '--wait', '--pipe', '--collect',
               '--service-type=exec', '--unit=' + args.unit,
               '--property=MemoryMax=' + str(memory), '--property=MemorySwapMax=0',
               '--property=TasksMax=128', '--property=CPUQuota=' + str(cpus * 100) + '%',
               '--property=CPUAffinity=' + ' '.join(str(cpu) for cpu in affinity),
               '--property=RuntimeMaxSec=' + str(args.timeout), '--property=TimeoutStopSec=5',
               '--property=KillMode=control-group', '--property=NoNewPrivileges=yes',
               '--property=OOMPolicy=kill', '--property=OOMScoreAdjust=1000',
               '--property=UMask=0077', '--', *nested]
    process = subprocess.Popen(command, env=user_environment(), stdin=subprocess.PIPE,
                               stdout=subprocess.PIPE if capture else None,
                               stderr=subprocess.PIPE if capture else None)
    def interrupted(signum, frame):
        raise RuntimeError('Sandbox launch interrupted')
    handlers = {sig: signal.signal(sig, interrupted) for sig in (signal.SIGTERM, signal.SIGHUP, signal.SIGINT)}
    try:
        deadline = time.monotonic() + 15
        while True:
            if process.poll() is not None:
                output, error = process.communicate()
                raise RuntimeError('systemd sandbox failed before its resource gate: ' + (error or b'').decode(errors='replace')[-4000:])
            if check_cgroup(args.unit, memory, cpus):
                break
            require(time.monotonic() < deadline, 'systemd sandbox resource gate timed out')
            time.sleep(0.05)
        process.stdin.write(b'1')
        process.stdin.close()
        process.stdin = None
        if capture:
            output, error = process.communicate(timeout=args.timeout + 10)
        else:
            process.wait(timeout=args.timeout + 10)
            output, error = b'', b''
        require(process.returncode == 0, 'Sandbox exited unsuccessfully: ' + error.decode(errors='replace')[-4000:])
        return output
    finally:
        for sig, handler in handlers.items():
            signal.signal(sig, handler)
        if process.stdin is not None:
            process.stdin.close()
        stop_unit(args.unit)
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()


def doctor(args):
    runtime, manifest = runtime_info(args, full=True)
    require(Path('/usr/bin/bwrap').is_file(), 'Install the Debian bubblewrap package')
    require(os.geteuid() != 0, 'Run doctor as the Panel owner, not root')
    probes = plain_path(args.state) / 'runner-probes'
    probes.mkdir(mode=0o700, exist_ok=True)
    outside = {name: os.readlink('/proc/self/ns/' + name) for name in ('user', 'mnt', 'pid', 'net', 'ipc', 'uts')}
    filters = 0
    for line in Path('/proc/self/status').read_text().splitlines():
        if line.startswith('Seccomp_filters:'):
            filters = int(line.split(':', 1)[1])
    with tempfile.TemporaryDirectory(prefix='doctor-', dir=probes) as directory:
        stage = Path(directory) / 'stage'; job = Path(directory) / 'job'
        for path in (stage, stage / 'storage', stage / 'bootstrap/cache', stage / 'public/assets', job):
            path.mkdir(parents=True, mode=0o700, exist_ok=True)
        (stage / 'readonly-canary').write_text('must remain unchanged')
        args.stage, args.job, args.memory, args.cpus, args.timeout = str(stage), str(job), '512m', '1', 30
        args.profile, args.unit = 'doctor', 'addon-manager-stage-' + os.urandom(10).hex() + '.service'
        report = json.loads(run_profile(args, capture=True))
        require(report.get('passed') is True and report.get('seccompFilters', 0) > filters, 'Sandbox seccomp self-test failed')
        require(all(report['namespaces'][name] != outside[name] for name in outside), 'A required namespace was not isolated')
        require((stage / 'readonly-canary').read_text() == 'must remain unchanged', 'Readonly stage binding failed')
        args.profile, args.unit = 'doctor-node', 'addon-manager-stage-' + os.urandom(10).hex() + '.service'
        node = json.loads(run_profile(args, capture=True))
        require(node.get('passed') is True, 'Node/Yarn runtime self-test failed')
    return {'ready': True, 'mode': 'bubblewrap', 'checks': [
        {'name': 'isolation', 'passed': True, 'message': 'Single-ID user namespace; private mounts, PIDs, networking, IPC and UTS.'},
        {'name': 'seccomp', 'passed': True, 'message': 'No-new-privileges, no capabilities, and the pinned syscall filter are enforced.'},
        {'name': 'resources', 'passed': True, 'message': 'Actual memory, swap, CPU and PID limits are checked before each sandbox executes code.'},
        {'name': 'runtime', 'passed': True, 'message': 'Immutable PHP ' + report['phpVersion'] + ', Node ' + node['nodeVersion'] + ' and Yarn ' + node['yarnVersion'] + ' passed isolated checks.'},
    ]}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['doctor', 'run', 'inside', 'stop'])
    parser.add_argument('--profile', choices=['php', 'node', 'doctor', 'doctor-node'], default='php')
    parser.add_argument('--unit')
    parser.add_argument('--runtime')
    parser.add_argument('--digest')
    parser.add_argument('--panel', default='/var/www/pterodactyl')
    parser.add_argument('--state', default='/var/www/pterodactyl/storage/app/addon-manager')
    parser.add_argument('--stage')
    parser.add_argument('--job')
    parser.add_argument('--memory', default='512m')
    parser.add_argument('--cpus', default='2')
    parser.add_argument('--timeout', type=int, default=300)
    args = parser.parse_args()
    if args.action == 'stop':
        stop_unit(args.unit)
    elif args.action == 'inside':
        inside(args)
    elif args.action == 'doctor':
        print(json.dumps(doctor(args)))
    else:
        run_profile(args)


if __name__ == '__main__':
    try:
        main()
    except (Exception, KeyboardInterrupt) as error:
        print('Native runner: ' + str(error), file=sys.stderr, flush=True)
        sys.exit(1)
