#!/usr/bin/python3
"""Install the bundled single-ID runner inside the existing Panel LXC only.

Usage: python3 install-runner.py [apply|rollback]
The working systemd workerControl settings and existing queue/FPM units are retained.
"""
import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import pwd
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time

PACKAGE = Path(__file__).resolve().parent
PANEL = Path('/var/www/pterodactyl')
STATE = PANEL / 'storage/app/addon-manager'
HOST = STATE / 'host.json'
SOURCE = PANEL / 'addon-manager/src/Runner/IsolatedRunner.php'
LAUNCHER = Path('/usr/local/libexec/addon-manager-bubblewrap.py')
BACKUP = Path('/var/lib/addon-manager-lxc-patch')
RUNTIMES = Path('/var/lib/addon-manager-runner/runtimes')
MANAGER = 'addon-manager.service'


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def say(message):
    print(message, flush=True)


def run(args, *, capture=False, check=True, input=None, timeout=None):
    environment = os.environ.copy()
    environment.update(DEBIAN_FRONTEND='noninteractive', NEEDRESTART_MODE='l')
    result = subprocess.run([str(x) for x in args], cwd='/', env=environment, text=True, input=input,
                            stdout=subprocess.PIPE if capture else None,
                            stderr=subprocess.PIPE if capture else None, timeout=timeout)
    if check and result.returncode:
        diagnostic = ((result.stderr or '') + (result.stdout or '')).strip()[-6000:]
        raise RuntimeError(f'{args[0]} exited {result.returncode}: {diagnostic}')
    return result


def panel(args, **kwargs):
    return run(['runuser', '-u', 'www-data', '--', *args], **kwargs)


def digest(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def source_hash(path):
    return hashlib.sha256(path.read_bytes().replace(b'\r\n', b'\n').rstrip(b'\r\n') + b'\n').hexdigest()


def atomic(path, contents, *, mode=0o600, uid=0, gid=0):
    require(not path.is_symlink(), 'Refusing symlink: ' + str(path))
    if isinstance(contents, str):
        contents = contents.encode()
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name + '.', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(contents)
            handle.flush()
            os.fsync(handle.fileno())
            os.fchmod(handle.fileno(), mode)
            os.fchown(handle.fileno(), uid, gid)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def owned_directory(path, mode=0o755):
    require(not path.is_symlink(), 'Refusing symlink directory: ' + str(path))
    path.mkdir(parents=True, exist_ok=True)
    os.chown(path, 0, 0)
    os.chmod(path, mode)


def active(unit):
    return run(['systemctl', 'is-active', '--quiet', unit], check=False).returncode == 0


def doctor():
    result = panel(['/usr/bin/php', PANEL / 'addon-manager/bin/manager.php', '--panel-root=' + str(PANEL), 'doctor'], capture=True, check=False)
    atomic(BACKUP / 'doctor.json', result.stdout)
    try:
        return json.loads(result.stdout)
    except ValueError as error:
        raise RuntimeError('doctor did not return JSON; inspect ' + str(BACKUP / 'doctor.json')) from error


def metadata(path):
    info = path.stat()
    return {'mode': info.st_mode & 0o777, 'uid': info.st_uid, 'gid': info.st_gid}


def extract_runtime(archive_path, destination):
    require(not destination.exists(), 'Runtime destination already exists')
    owned_directory(destination)
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        require(sum(item.size for item in members) < 600 * 1024 ** 2, 'Runtime archive exceeds its size limit')
        for item in members:
            relative = PurePosixPath(item.name)
            require(not relative.is_absolute() and '..' not in relative.parts and item.name not in ('', '.'), 'Unsafe runtime archive path')
            require(item.isdir() or item.isfile() or item.islnk(), 'Unsupported runtime archive entry')
            target = destination.joinpath(*relative.parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            if item.isdir():
                owned_directory(target)
            elif item.islnk():
                link = PurePosixPath(item.linkname)
                require(not link.is_absolute() and '..' not in link.parts, 'Unsafe runtime hardlink')
                existing = destination.joinpath(*link.parts)
                require(existing.is_file() and not existing.is_symlink(), 'Invalid runtime hardlink target')
                os.link(existing, target)
            else:
                data = archive.extractfile(item)
                require(data is not None and not target.exists(), 'Duplicate runtime archive file')
                with target.open('xb') as handle:
                    shutil.copyfileobj(data, handle)
                os.chmod(target, 0o555 if item.mode & 0o111 else 0o444)
                os.chown(target, 0, 0)


def runtime_arguments(config):
    return ['--runtime', config['runtimeRoot'], '--digest', config['runtimeDigest'], '--panel', str(PANEL), '--state', str(STATE)]


def native_doctor(config):
    result = panel(['/usr/bin/python3', '-I', LAUNCHER, 'doctor', *runtime_arguments(config)], capture=True, timeout=120)
    report = json.loads(result.stdout)
    require(report.get('ready') is True and report.get('mode') == 'bubblewrap', 'Native sandbox self-tests did not pass')
    return report


def snapshot(uid, gid):
    registry = json.loads((STATE / 'registry.json').read_text())
    inventory = registry.get('baselineInventory')
    require(isinstance(inventory, dict) and inventory, 'Baseline inventory is not available for the private snapshot test')
    parent = STATE / 'runner-probes'
    parent.mkdir(mode=0o700, exist_ok=True)
    os.chown(parent, uid, gid)
    directory = Path(tempfile.mkdtemp(prefix='install-', dir=parent))
    os.chown(directory, uid, gid)
    stage = directory / 'stage'
    stage.mkdir(mode=0o700)
    os.chown(stage, uid, gid)
    def ensure_directory(path):
        pending = []
        while not path.exists():
            pending.append(path)
            path = path.parent
        for path in reversed(pending):
            path.mkdir(mode=0o700)
            os.chown(path, uid, gid)
    for relative in inventory:
        require(isinstance(relative, str), 'Invalid baseline inventory path')
        parts = PurePosixPath(relative).parts
        require(parts and not PurePosixPath(relative).is_absolute() and '..' not in parts, 'Unsafe baseline inventory path')
        if (parts[0] in ('.git', 'vendor', 'node_modules', 'addon-manager', 'storage')
                or parts[:2] == ('bootstrap', 'cache') or any(part.startswith('.env') for part in parts)):
            continue
        original = PANEL.joinpath(*parts)
        require(original.is_file() and str(original) == str(original.resolve(strict=True)), 'Source file is missing or linked: ' + relative)
        destination = stage.joinpath(*parts)
        ensure_directory(destination.parent)
        shutil.copyfile(original, destination)
        os.chmod(destination, 0o700 if original.stat().st_mode & 0o111 else 0o600)
        os.chown(destination, uid, gid)
    for name in ('storage', 'bootstrap/cache', 'public/assets'):
        ensure_directory(stage / name)
    return directory, stage


SMOKE = r'''
require $argv[1] . '/addon-manager/bootstrap.php';
$panel = $argv[1];
$runner = new AddonManager\Runner\IsolatedRunner($panel, $panel . '/storage/app/addon-manager', json_decode($argv[3], true, 512, JSON_THROW_ON_ERROR));
if ($argv[4] === 'build') {
    $result = $runner->build($argv[2], [], ['id'=>'runner-install-probe', 'buildPlan'=>['required'=>true,'profile'=>'panel-v1']]);
} else {
    $result = $runner->verifyStage($argv[2], [], ['id'=>'runner-install-probe']);
}
echo json_encode($result, JSON_THROW_ON_ERROR), "\n";
'''


def restore():
    transaction = json.loads((BACKUP / 'transaction.json').read_text())
    current = json.loads(HOST.read_text())
    require(current.get('runner') in (transaction['config'], transaction['previous_runner']), 'Runner configuration changed after installation; review the backup')
    require(source_hash(SOURCE) in (transaction['old_source_hash'], transaction['new_source_hash']), 'Runner source changed after this patch; review the backup')
    run(['systemctl', 'stop', MANAGER])
    atomic(SOURCE, (BACKUP / 'IsolatedRunner.php').read_bytes(), **transaction['source'])
    if transaction['had_runner']:
        current['runner'] = transaction['previous_runner']
    else:
        current.pop('runner', None)
    atomic(HOST, json.dumps(current, indent=4) + '\n', **transaction['host'])
    if transaction['manager_active']:
        run(['systemctl', 'start', MANAGER])
    atomic(BACKUP / 'rolled-back', '1\n')
    say('Previous runner source/configuration restored. Native systemd worker control and queue/FPM units retained.')


def apply():
    package = json.loads((PACKAGE / 'runner-package.json').read_text())
    if (BACKUP / 'complete').exists() and not (BACKUP / 'rolled-back').exists():
        report = doctor()
        require(report.get('host', {}).get('runner', {}).get('ready') is True
                and report.get('host', {}).get('runner', {}).get('mode') == 'bubblewrap', 'Installed native runner now fails doctor')
        say('The native runner is already installed and passes doctor.')
        return
    require(not (BACKUP / 'transaction.json').exists(), 'A previous runner transaction exists; use rollback or review its backup')
    require(os.uname().machine == 'x86_64', 'This package contains an x86_64 runtime')
    require('VERSION_ID="12"' in Path('/etc/os-release').read_text() and 'ID=debian' in Path('/etc/os-release').read_text(), 'This runtime targets Debian 12')
    require(source_hash(SOURCE) == package['oldRunnerHash'], 'Runner source differs from the pasted 2.0.1 version; no patch applied')
    require(not LAUNCHER.exists() or digest(LAUNCHER) == package['files']['bubblewrap-launcher.py'],
            'A pre-existing native launcher needs review')
    for name, expected in package['files'].items():
        require(digest(PACKAGE / name) == expected, 'Package file fingerprint mismatch: ' + name)
    report = doctor()
    require(report.get('manager', {}).get('ok') is True, 'Resolve manager integrity/recovery checks before patching the runner')
    control = report.get('host', {}).get('workerControl', {})
    require(control.get('driver') == 'systemd' and control.get('ready') is True, 'Install the working native systemd control patch first')
    require(report.get('host', {}).get('worker', {}).get('status') == 'idle', 'Wait until the manager worker is idle before patching its runner')
    require(shutil.disk_usage('/var/lib').free > 1024 ** 3 and shutil.disk_usage(STATE).free > 1024 ** 3,
            'At least 1 GiB free space is required for the runtime and private snapshot')
    uid, gid = pwd.getpwnam('www-data').pw_uid, pwd.getpwnam('www-data').pw_gid
    if not Path('/usr/bin/bwrap').exists():
        say('Installing the guest-local Debian bubblewrap package.')
        run(['apt-get', 'install', '-y', '--no-install-recommends', 'bubblewrap'])
    for path in (RUNTIMES.parent, RUNTIMES):
        owned_directory(path)
    runtime = RUNTIMES / package['runtimeDigest'].split(':', 1)[1]
    if not runtime.exists():
        say('Installing the private PHP 8.3.36 / Node 22 runtime; the serving PHP installation is unchanged.')
        try:
            extract_runtime(PACKAGE / 'runtime.tar.gz', runtime)
        except BaseException:
            if runtime.exists(): shutil.rmtree(runtime)
            raise
    require('sha256:' + digest(runtime / 'runtime-manifest.json') == package['runtimeDigest'], 'Runtime manifest fingerprint mismatch')
    run(['/usr/bin/python3', PACKAGE / 'seccomp-compile.py', runtime / 'seccomp-profile.json', runtime / 'sandbox.bpf'])
    os.chmod(runtime / 'sandbox.bpf', 0o444)
    if not LAUNCHER.parent.exists():
        owned_directory(LAUNCHER.parent)
    else:
        info = LAUNCHER.parent.stat()
        require(not LAUNCHER.parent.is_symlink() and info.st_uid == 0 and info.st_mode & 0o022 == 0,
                'Launcher directory must be root-owned and not writable by other users')
    atomic(LAUNCHER, (PACKAGE / 'bubblewrap-launcher.py').read_bytes(), mode=0o755)
    config = {'mode':'bubblewrap', 'runtimeRoot':str(runtime), 'runtimeDigest':package['runtimeDigest'],
              'memory':'512m','buildMemory':'2g','cpus':2,'timeout':300}
    say('Checking isolated PHP/Node, readonly files, namespaces, syscall filtering, and actual systemd resource limits.')
    native_doctor(config)
    shutil.copy2(SOURCE, BACKUP / 'IsolatedRunner.php')
    shutil.copy2(HOST, BACKUP / 'host.json')
    before = json.loads(HOST.read_text())
    transaction = {'source':metadata(SOURCE),'host':metadata(HOST),'old_source_hash':source_hash(SOURCE),
                   'new_source_hash':package['newRunnerHash'], 'had_runner':'runner' in before,
                   'previous_runner':before.get('runner'), 'config':config,'manager_active':active(MANAGER)}
    atomic(BACKUP / 'transaction.json', json.dumps(transaction) + '\n')
    directory = None
    try:
        run(['systemctl', 'stop', MANAGER])
        atomic(SOURCE, (PACKAGE / 'IsolatedRunner.php').read_bytes(), **transaction['source'])
        directory, stage = snapshot(uid, gid)
        say('Testing an isolated PHP Panel boot against a private source snapshot.')
        panel(['/usr/bin/php', '-r', SMOKE, str(PANEL), str(stage), json.dumps(config), 'verify'], capture=True, timeout=330)
        if (PANEL / 'node_modules/.bin/webpack').is_file():
            say('Testing the existing frontend dependencies inside the private snapshot; live assets are untouched.')
            panel(['/usr/bin/php', '-r', SMOKE, str(PANEL), str(stage), json.dumps(config), 'build'], capture=True, timeout=330)
        else:
            say('Frontend dependencies are absent; frontend addon builds still require the matched frozen node_modules.')
        current = json.loads(HOST.read_text())
        current['runner'] = config
        atomic(HOST, json.dumps(current, indent=4) + '\n', **transaction['host'])
        run(['systemctl', 'start', MANAGER])
        deadline = time.monotonic() + 45
        while True:
            report = doctor()
            worker_pid = int(run(['systemctl','show',MANAGER,'--property=MainPID','--value'],capture=True).stdout.strip())
            if (report.get('host',{}).get('ready') is True and report.get('manager',{}).get('ok') is True
                    and worker_pid > 0 and report.get('host',{}).get('worker',{}).get('pid') == worker_pid):
                break
            require(time.monotonic() < deadline, 'Final doctor did not confirm full readiness; see the saved doctor.json')
            time.sleep(1)
        # Retire only the failed user Docker unit created by the earlier setup.
        old_user_unit = Path('/var/www/.config/systemd/user/docker.service')
        if old_user_unit.is_file() and old_user_unit.read_text().startswith('# Managed by setup-panel-addon-host.py'):
            panel(['/usr/bin/env',f'XDG_RUNTIME_DIR=/run/user/{uid}',f'DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/{uid}/bus',
                   '/usr/bin/systemctl','--user','disable','--now','docker.service'],check=False)
        atomic(BACKUP / 'complete','1\n')
        say('Ready: runner=bubblewrap, workerControl=systemd, host.ready=true, manager.ok=true.')
        say('No Proxmox-host edits, subordinate-ID changes, or queue/FPM unit changes were made.')
        say('Old Docker packages remain installed but are not used by this runner. The Arix preset advisory remains unchanged.')
    except BaseException:
        say('Runner patch failed; restoring the previous runner source/configuration.')
        try:
            restore()
        except BaseException as error:
            say('Rollback needs attention: ' + str(error))
            say('Use: python3 install-runner.py rollback')
        raise
    finally:
        if directory is not None and directory.exists():
            shutil.rmtree(directory)


def main():
    require(os.geteuid() == 0, 'Run this installer as root inside the Panel LXC')
    require(len(sys.argv) <= 2 and (len(sys.argv) == 1 or sys.argv[1] in ('apply','rollback')), 'Usage: python3 install-runner.py [apply|rollback]')
    require(SOURCE.is_file() and HOST.is_file(), 'Installed Panel/manager not found')
    os.umask(0o022)
    owned_directory(BACKUP,0o700)
    with (BACKUP / 'lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX | fcntl.LOCK_NB)
        restore() if sys.argv[-1] == 'rollback' else apply()


if __name__ == '__main__':
    try:
        main()
    except (Exception,KeyboardInterrupt) as error:
        print('STOP: '+str(error),file=sys.stderr,flush=True)
        sys.exit(1)
