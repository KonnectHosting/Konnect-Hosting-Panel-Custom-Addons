#!/usr/bin/python3
"""Compile the bundled Moby profile for this native architecture and no capabilities."""
import ctypes
import ctypes.util
import json
import os
import platform
import sys


def compile_profile(source, destination):
    profile = json.load(open(source, encoding='utf-8'))
    if profile['defaultAction'] != 'SCMP_ACT_ERRNO':
        raise RuntimeError('Unexpected seccomp default action')
    lib = ctypes.CDLL(ctypes.util.find_library('seccomp') or 'libseccomp.so.2', use_errno=True)
    lib.seccomp_init.argtypes = [ctypes.c_uint32]
    lib.seccomp_init.restype = ctypes.c_void_p
    lib.seccomp_syscall_resolve_name.argtypes = [ctypes.c_char_p]
    lib.seccomp_syscall_resolve_name.restype = ctypes.c_int
    lib.seccomp_rule_add_array.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int, ctypes.c_uint, ctypes.c_void_p]
    lib.seccomp_export_bpf.argtypes = [ctypes.c_void_p, ctypes.c_int]
    lib.seccomp_release.argtypes = [ctypes.c_void_p]
    class Comparison(ctypes.Structure):
        _fields_ = [('arg', ctypes.c_uint), ('op', ctypes.c_int), ('datum_a', ctypes.c_uint64), ('datum_b', ctypes.c_uint64)]
    operators = {'SCMP_CMP_NE': 1, 'SCMP_CMP_LT': 2, 'SCMP_CMP_LE': 3, 'SCMP_CMP_EQ': 4,
                 'SCMP_CMP_GE': 5, 'SCMP_CMP_GT': 6, 'SCMP_CMP_MASKED_EQ': 7}
    arch = {'x86_64': 'amd64', 'aarch64': 'arm64'}.get(platform.machine(), platform.machine())
    kernel = tuple(int(x) for x in platform.release().split('-')[0].split('.')[:2])
    default = 0x00050000 | profile.get('defaultErrnoRet', 1)
    context = lib.seccomp_init(default)
    if not context:
        raise RuntimeError('Cannot initialize seccomp')
    added = 0
    try:
        for rule in profile['syscalls']:
            include, exclude = rule.get('includes', {}), rule.get('excludes', {})
            if include.get('caps'):
                continue
            if include.get('arches') and arch not in include['arches']:
                continue
            if arch in exclude.get('arches', []):
                continue
            minimum = include.get('minKernel')
            if minimum and kernel < tuple(int(x) for x in minimum.split('.')[:2]):
                continue
            if rule['action'] == 'SCMP_ACT_ALLOW':
                action = 0x7fff0000
            elif rule['action'] == 'SCMP_ACT_ERRNO':
                action = 0x00050000 | rule.get('errnoRet', profile.get('defaultErrnoRet', 1))
            else:
                raise RuntimeError('Unsupported seccomp rule action')
            args = rule.get('args', [])
            conditions = (Comparison * len(args))(*[Comparison(a['index'], operators[a['op']], a['value'], a.get('valueTwo', 0)) for a in args])
            for name in rule['names']:
                number = lib.seccomp_syscall_resolve_name(name.encode())
                # A profile may name calls from newer kernels or other architectures.
                if number < 0:
                    continue
                if action == default:
                    continue
                result = lib.seccomp_rule_add_array(context, action, number, len(args), conditions)
                if result < 0:
                    raise RuntimeError(f'Cannot add seccomp rule {name}: {-result}')
                added += 1
        fd = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o644)
        try:
            if lib.seccomp_export_bpf(context, fd) < 0:
                raise RuntimeError('Cannot export seccomp filter')
        finally:
            os.close(fd)
    finally:
        lib.seccomp_release(context)
    return added


if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('Usage: seccomp-compile.py profile.json filter.bpf')
    print('Compiled', compile_profile(sys.argv[1], sys.argv[2]), 'seccomp rules')
