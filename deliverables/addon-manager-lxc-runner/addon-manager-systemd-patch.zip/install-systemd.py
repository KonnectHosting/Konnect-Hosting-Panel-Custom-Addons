#!/usr/bin/env python3
"""Apply the accompanying WorkerControl.php to the known Addon Manager 2.0.1 host.

Usage: python3 install-systemd.py [apply|rollback]
Only the manager worker is restarted. Existing queue/FPM units are not changed.
"""

import fcntl
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import shutil
import subprocess
import sys
import tempfile
import time

PANEL = Path('/var/www/pterodactyl')
CONTROL = PANEL / 'addon-manager/src/Laravel/WorkerControl.php'
HOST = PANEL / 'storage/app/addon-manager/host.json'
BACKUP = Path('/var/lib/addon-manager-systemd-patch')
UNIT = Path('/etc/systemd/system/panel-scheduler.service')
SUDOERS = Path('/etc/sudoers.d/addon-manager-systemd')
CONFIG = {'driver': 'systemd', 'binary': '/usr/bin/systemctl',
          'units': ['panel-scheduler.service', 'pteroq.service', 'php8.3-fpm.service'], 'timeout': 180}
OLD_SHA = 'f59b397657d11c468f9a7e60b4459d9f19b31b21c6af4ff86eeaf050238a5c7d'
NEW_SHA = '74570141c2f3f99a6937d71e6c3d49c32ca0c63762a6ee2fe4b529ca109a5db5'
SCHEDULER = '''# Addon Manager systemd scheduler, installed by install-systemd.py
[Unit]
Description=Pterodactyl Panel scheduler
Wants=network-online.target
After=network-online.target pteroq.service php8.3-fpm.service

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/var/www/pterodactyl
ExecStart=/usr/bin/php /var/www/pterodactyl/artisan schedule:work
Restart=on-failure
RestartSec=5
KillMode=control-group
TimeoutStopSec=90
UMask=0077

[Install]
WantedBy=multi-user.target
'''
POLICY = '# Exact Panel service commands only; no wildcard or daemon-reload permission.\n' + '\n'.join(
    f'www-data ALL=(root) NOPASSWD: /usr/bin/systemctl --system {verb} -- {unit}'
    for unit in CONFIG['units'] for verb in ('start', 'stop')) + '\n'


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def run(args, *, capture=False, check=True, input=None):
    result = subprocess.run([str(arg) for arg in args], text=True, input=input,
                            stdout=subprocess.PIPE if capture else None,
                            stderr=subprocess.PIPE if capture else None, cwd='/')
    if check and result.returncode:
        raise RuntimeError(f'{args[0]} exited {result.returncode}: {(result.stderr or "").strip()[-2000:]}')
    return result


def panel(args, **kwargs):
    return run(['runuser', '-u', 'www-data', '--', *args], **kwargs)


def normalized_hash(data):
    return hashlib.sha256(data.replace(b'\r\n', b'\n').rstrip(b'\r\n') + b'\n').hexdigest()


def atomic(path, data, mode=0o600, uid=0, gid=0):
    require(not path.is_symlink(), f'Refusing symlink: {path}')
    if isinstance(data, str):
        data = data.encode()
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name + '.', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
            os.fchmod(handle.fileno(), mode)
            os.fchown(handle.fileno(), uid, gid)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def active(unit):
    return run(['systemctl', 'is-active', '--quiet', unit], check=False).returncode == 0


def doctor():
    result = panel(['/usr/bin/php', PANEL / 'addon-manager/bin/manager.php',
                    '--panel-root=' + str(PANEL), 'doctor'], capture=True, check=False)
    atomic(BACKUP / 'doctor.json', result.stdout)
    try:
        report = json.loads(result.stdout)
        require(isinstance(report, dict), 'doctor must return an object')
        return report
    except (ValueError, RuntimeError) as error:
        raise RuntimeError('doctor did not return usable JSON; see ' + str(BACKUP / 'doctor.json')) from error


def crontab():
    return run(['crontab', '-u', 'www-data', '-l'], capture=True).stdout


def prepare_cron(before):
    canonical = re.compile(r'^\*\s+\*\s+\*\s+\*\s+\*\s+(?:/usr/bin/)?php(?:8\.3)?\s+/var/www/pterodactyl/artisan\s+schedule:run\s*(?:>>?\s*/dev/null\s+2>&1)?\s*$')
    after, matched = [], 0
    for line in before.splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith('#'):
            assignment = re.match(r'^([A-Za-z_][A-Za-z0-9_]*)\s*=', stripped)
            require(not assignment or assignment.group(1) in ('PATH', 'SHELL', 'MAILTO'),
                    'Custom scheduler environment requires review before moving cron to systemd')
            if 'artisan' in stripped and 'schedule:' in stripped:
                require(canonical.fullmatch(stripped) is not None, 'Custom cron command requires a reviewed scheduler handover')
                matched += 1
                after.extend(['# Addon Manager: scheduler now uses panel-scheduler.service', '# ' + line])
                continue
        after.append(line)
    require(matched == 1, 'Expected one standard www-data Panel schedule:run cron entry')
    for path in [Path('/etc/crontab'), *Path('/etc/cron.d').glob('*'), *Path('/var/spool/cron/crontabs').glob('*')]:
        if path == Path('/var/spool/cron/crontabs/www-data') or not path.is_file():
            continue
        for line in path.read_text(errors='replace').splitlines():
            require(not (line.strip() and not line.lstrip().startswith('#') and str(PANEL) in line and 'schedule:' in line),
                    f'An additional Panel scheduler in {path} needs review')
    return '\n'.join(after) + '\n'


def drain_old_scheduler(uid):
    deadline = time.monotonic() + 90
    quiet_since = None
    managed = ['/system.slice/' + name for name in
               ('pteroq.service', 'php8.3-fpm.service', 'nginx.service', 'addon-manager.service')]
    managed.append(f'/user.slice/user-{uid}.slice/user@{uid}.service')
    while True:
        found = False
        for process in Path('/proc').glob('[0-9]*'):
            try:
                if process.stat().st_uid != uid:
                    continue
                groups = [line.split(':', 2)[-1] for line in process.joinpath('cgroup').read_text().splitlines()]
                if not any(group == prefix or group.startswith(prefix + '/') for group in groups for prefix in managed):
                    # Queue/FPM descendants stay in controlled service cgroups. Drain other
                    # www-data work, including old cron children whose dispatcher has exited.
                    found = True
            except (FileNotFoundError, ProcessLookupError):
                pass
            except PermissionError:
                found = True
        if not found:
            quiet_since = quiet_since or time.monotonic()
            if time.monotonic() - quiet_since >= 5:
                return
        else:
            quiet_since = None
        require(time.monotonic() < deadline, 'Existing www-data work outside controlled services did not drain in 90 seconds; restoring cron')
        time.sleep(1)


def restore():
    require((BACKUP / 'transaction.json').exists(), 'No systemd patch backup exists')
    transaction = json.loads((BACKUP / 'transaction.json').read_text())
    require(normalized_hash(CONTROL.read_bytes()) in (OLD_SHA, NEW_SHA), 'Manager control source changed after this patch; review the saved backup')
    current = crontab()
    require(current in ((BACKUP / 'cron.before').read_text(), (BACKUP / 'cron.after').read_text()),
            'Crontab changed after installation; retain it and reconcile the saved backup')
    if UNIT.exists():
        require(UNIT.read_text() == SCHEDULER, 'Scheduler unit changed; review it before rollback')
    if SUDOERS.exists():
        require(SUDOERS.read_text() == POLICY, 'Service policy changed; review it before rollback')
    data = json.loads(HOST.read_text())
    require(data.get('workerControl') in (CONFIG, transaction['previous_control']), 'workerControl changed after installation; review its backup')
    run(['systemctl', 'stop', 'addon-manager.service'])
    if UNIT.exists():
        run(['systemctl', 'disable', '--now', 'panel-scheduler.service'])
        UNIT.unlink()
    if SUDOERS.exists():
        SUDOERS.unlink()
    metadata = transaction['source']
    atomic(CONTROL, (BACKUP / 'WorkerControl.php').read_bytes(), metadata['mode'], metadata['uid'], metadata['gid'])
    data = json.loads(HOST.read_text())
    if transaction['had_control']:
        data['workerControl'] = transaction['previous_control']
    else:
        data.pop('workerControl', None)
    metadata = transaction['host']
    atomic(HOST, json.dumps(data, indent=4) + '\n', metadata['mode'], metadata['uid'], metadata['gid'])
    run(['systemctl', 'daemon-reload'])
    run(['crontab', '-u', 'www-data', '-'], input=(BACKUP / 'cron.before').read_text())
    if transaction['manager_active']:
        run(['systemctl', 'start', 'addon-manager.service'])
    atomic(BACKUP / 'rolled-back', '1\n')
    print('Previous manager control and cron restored. Existing queue/FPM systemd units were retained.', flush=True)


def apply():
    if (BACKUP / 'complete').exists() and not (BACKUP / 'rolled-back').exists():
        report = doctor()
        result = report.get('host', {}).get('workerControl', {})
        require(normalized_hash(CONTROL.read_bytes()) == NEW_SHA
                and result.get('driver') == 'systemd' and result.get('ready') is True,
                'Previously installed control now fails doctor; inspect ' + str(BACKUP / 'doctor.json'))
        print('Native systemd control is already installed and passes doctor.', flush=True)
        return
    require(not (BACKUP / 'transaction.json').exists(), 'A prior transaction exists; use rollback or review its backup')
    require(normalized_hash(CONTROL.read_bytes()) == OLD_SHA, 'WorkerControl.php differs from the pasted 2.0.1 source; no patch applied')
    payload = Path(__file__).resolve().with_name('WorkerControl.php')
    require(payload.is_file() and normalized_hash(payload.read_bytes()) == NEW_SHA, 'Matching WorkerControl.php must be next to this installer')
    require(not UNIT.exists() and not SUDOERS.exists(), 'An existing scheduler unit or service policy needs review')
    require(not (PANEL / 'storage/framework/down').exists(), 'Panel is in maintenance; finish recovery before patching control')
    for command in ('/usr/bin/systemctl', '/usr/bin/sudo', '/usr/sbin/visudo', '/usr/bin/php'):
        require(os.access(command, os.X_OK), f'Required executable is missing: {command}')
    for unit in ('pteroq.service', 'php8.3-fpm.service'):
        require(active(unit), f'{unit} must be running before this patch')
        props = run(['systemctl', 'show', '--all', '--property=KillMode,SendSIGKILL', unit], capture=True).stdout
        require('KillMode=control-group\n' in props and 'SendSIGKILL=yes\n' in props, f'{unit} requires process-group shutdown')
    load = run(['systemctl', 'show', '--property=LoadState', '--value', 'panel-scheduler.service'], capture=True, check=False).stdout.strip()
    require(load == 'not-found', 'An existing panel-scheduler.service needs review')
    report = doctor()
    require(report.get('manager', {}).get('ok') is True, 'Resolve manager integrity/recovery checks before changing its control driver')
    panel(['/usr/bin/php', PANEL / 'artisan', 'help', 'schedule:work'], capture=True)
    run(['/usr/bin/php', '-l', payload])
    before = crontab()
    after = prepare_cron(before)
    atomic(BACKUP / 'sudoers.candidate', POLICY, 0o440)
    run(['/usr/sbin/visudo', '-cf', BACKUP / 'sudoers.candidate'])
    shutil.copy2(CONTROL, BACKUP / 'WorkerControl.php')
    shutil.copy2(HOST, BACKUP / 'host.json')
    atomic(BACKUP / 'cron.before', before)
    atomic(BACKUP / 'cron.after', after)
    def metadata(path):
        info = path.stat()
        return {'uid': info.st_uid, 'gid': info.st_gid, 'mode': info.st_mode & 0o777}
    data = json.loads(HOST.read_text())
    transaction = {'source': metadata(CONTROL), 'host': metadata(HOST),
                   'manager_active': active('addon-manager.service'),
                   'had_control': 'workerControl' in data, 'previous_control': data.get('workerControl')}
    atomic(BACKUP / 'transaction.json', json.dumps(transaction) + '\n')
    try:
        run(['systemctl', 'stop', 'addon-manager.service'])
        atomic(UNIT, SCHEDULER, 0o644)
        atomic(SUDOERS, POLICY, 0o440)
        metadata = transaction['source']
        atomic(CONTROL, payload.read_bytes(), metadata['mode'], metadata['uid'], metadata['gid'])
        run(['crontab', '-u', 'www-data', '-'], input=after)
        print('Waiting for the previous cron scheduler to finish; queue/FPM keep running.', flush=True)
        drain_old_scheduler(pwd.getpwnam('www-data').pw_uid)
        run(['systemctl', 'daemon-reload'])
        run(['systemctl', 'enable', '--now', 'panel-scheduler.service'])
        data = json.loads(HOST.read_text())
        data['workerControl'] = CONFIG
        metadata = transaction['host']
        atomic(HOST, json.dumps(data, indent=4) + '\n', metadata['mode'], metadata['uid'], metadata['gid'])
        run(['systemctl', 'start', 'addon-manager.service'])
        report = doctor()
        result = report.get('host', {}).get('workerControl', {})
        require(result.get('driver') == 'systemd' and result.get('ready') is True,
                'Native control failed its doctor checks; inspect ' + str(BACKUP / 'doctor.json'))
        require(report.get('manager', {}).get('ok') is True, 'Manager integrity check failed after patching')
        atomic(BACKUP / 'complete', '1\n')
        print('workerControl: driver=systemd, ready=true. Existing queue/FPM units are retained.', flush=True)
        if report.get('host', {}).get('runner', {}).get('ready') is not True:
            print('The isolated Docker runner is still a separate readiness blocker.', flush=True)
            print('Recent rootless Docker startup log:', flush=True)
            # Read-only diagnostics for the already-reported runner failure.
            run(['journalctl', '--no-pager', '-b', '-n', '40',
                 '_UID=' + str(pwd.getpwnam('www-data').pw_uid),
                 '_SYSTEMD_USER_UNIT=docker.service'], check=False)
    except BaseException:
        print('Patch failed; attempting to restore the saved control and cron.', flush=True)
        try:
            restore()
        except BaseException as error:
            print('Rollback needs attention: ' + str(error), file=sys.stderr)
            print('Use this installer with the rollback argument after reviewing the saved backup.', file=sys.stderr)
        raise


def main():
    require(os.geteuid() == 0, 'Run as root on the Panel server')
    require(len(sys.argv) <= 2 and (len(sys.argv) == 1 or sys.argv[1] in ('apply', 'rollback')),
            'Usage: python3 install-systemd.py [apply|rollback]')
    require(CONTROL.is_file() and HOST.is_file(), 'Installed Addon Manager not found')
    require(not BACKUP.is_symlink(), 'Backup path must not be a symlink')
    os.umask(0o022)
    BACKUP.mkdir(mode=0o700, exist_ok=True)
    os.chmod(BACKUP, 0o700)
    with open(BACKUP / 'lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        restore() if sys.argv[-1] == 'rollback' else apply()


if __name__ == '__main__':
    try:
        main()
    except (Exception, KeyboardInterrupt) as error:
        print('STOP: ' + str(error), file=sys.stderr, flush=True)
        sys.exit(1)
