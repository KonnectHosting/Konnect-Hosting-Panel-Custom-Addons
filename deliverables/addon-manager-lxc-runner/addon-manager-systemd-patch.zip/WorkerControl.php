<?php

declare(strict_types=1);

namespace AddonManager\Laravel;

use RuntimeException;

/** Host-owned service policy. No command or service names originate in packages. */
final class WorkerControl
{
    private string $driver = 'supervisor';
    private string $binary;
    private array $groups = [];
    private array $units = [];
    private int $timeout = 30;

    public function __construct(array $settings)
    {
        if (($settings['driver'] ?? null) === 'systemd') {
            $this->configureSystemd($settings);
            return;
        }
        if (($settings['driver'] ?? null) !== 'supervisor' || array_diff(array_keys($settings), ['driver', 'binary', 'groups', 'timeout']) !== []) {
            throw new RuntimeException('Configure host workerControl {driver:"supervisor",groups:["pteroq","panel-php-fpm"]} with narrowly scoped supervisor permission for the deployment worker.');
        }
        $timeout = array_key_exists('timeout', $settings) ? $settings['timeout'] : 30;
        if (!is_int($timeout) || $timeout < 1 || $timeout > 300) {
            throw new RuntimeException('Supervisor timeout must be an integer between 1 and 300 seconds.');
        }
        $this->timeout = $timeout;
        $this->binary = $settings['binary'] ?? '/usr/bin/supervisorctl';
        if (!in_array($this->binary, ['/usr/bin/supervisorctl', '/usr/local/bin/supervisorctl'], true) || !is_executable($this->binary)) {
            throw new RuntimeException('Supported supervisorctl binary is unavailable.');
        }
        $this->groups = $settings['groups'] ?? [];
        if (!is_array($this->groups) || !array_is_list($this->groups) || count($this->groups) < 2 || count($this->groups) > 16 || count(array_unique($this->groups)) !== count($this->groups)) {
            throw new RuntimeException('Configure separate affected Panel queue and PHP-FPM supervisor groups; exclude the management worker.');
        }
        foreach ($this->groups as $group) {
            if (!is_string($group) || !preg_match('/^[A-Za-z][A-Za-z0-9_-]{0,63}$/D', $group) || str_contains(strtolower(str_replace(['-', '_'], '', $group)), 'addonmanager')) {
                throw new RuntimeException('Invalid or management-worker supervisor group.');
            }
        }
    }

    public function doctor(): array
    {
        if ($this->driver === 'systemd') {
            return $this->doctorSystemd();
        }
        $checks = [];
        foreach ($this->groups as $group) {
            try {
                $response = $this->run('status', $group);
                $states = $this->states($response['output']);
                $checks[] = ['group' => $group, 'passed' => $response['exit'] === 0 && $states !== [] && array_diff($states, ['RUNNING']) === [], 'message' => 'Supervisor status permission and running affected services are required for this group.'];
            } catch (RuntimeException $e) {
                $checks[] = ['group' => $group, 'passed' => false, 'message' => $e->getMessage()];
            }
        }
        return ['ready' => count(array_filter($checks, static fn (array $check) => !$check['passed'])) === 0, 'driver' => 'supervisor', 'checks' => $checks];
    }

    public function stop(): array
    {
        if ($this->driver === 'systemd') {
            return $this->stopSystemd();
        }
        $stopped = [];
        foreach ($this->groups as $group) {
            $status = $this->run('status', $group);
            $states = $this->states($status['output']);
            if ($states !== [] && array_diff($states, ['STOPPED']) === []) {
                $stopped[] = $group;
                continue;
            }
            $this->run('stop', $group);
            $status = $this->run('status', $group);
            $states = $this->states($status['output']);
            if ($states === [] || array_diff($states, ['STOPPED']) !== []) {
                // Never restart earlier groups here: callers may be preparing rollback.
                throw new RuntimeException('Affected Panel group has not quiesced: ' . $group . '; keep maintenance and stopped services until recovery.');
            }
            $stopped[] = $group;
        }
        return ['stopped' => $stopped];
    }

    public function start(): array
    {
        if ($this->driver === 'systemd') {
            return $this->startSystemd();
        }
        $started = [];
        try {
            foreach (array_reverse($this->groups) as $group) {
                $this->run('start', $group);
                $status = $this->run('status', $group);
                $states = $this->states($status['output']);
                if ($states === [] || array_diff($states, ['RUNNING']) !== []) {
                    throw new RuntimeException('Supervisor could not start affected Panel group ' . $group . '; keep maintenance until service recovery.');
                }
                $started[] = $group;
            }
        } catch (RuntimeException $e) {
            $this->stop();
            throw $e;
        }
        return ['started' => $started];
    }

    private function configureSystemd(array $settings): void
    {
        if (array_diff(array_keys($settings), ['driver', 'binary', 'units', 'timeout']) !== []) {
            throw new RuntimeException('Unknown systemd workerControl setting.');
        }
        $this->driver = 'systemd';
        $this->binary = $settings['binary'] ?? '/usr/bin/systemctl';
        if (!in_array($this->binary, ['/usr/bin/systemctl', '/bin/systemctl'], true) || !is_executable($this->binary) || !is_executable('/usr/bin/sudo')) {
            throw new RuntimeException('systemd service control requires systemctl and sudo.');
        }
        $timeout = $settings['timeout'] ?? 180;
        if (!is_int($timeout) || $timeout < 1 || $timeout > 300) {
            throw new RuntimeException('Systemd timeout must be an integer between 1 and 300 seconds.');
        }
        $this->timeout = $timeout;
        $units = $settings['units'] ?? [];
        if (!is_array($units) || !array_is_list($units) || count($units) < 2 || count($units) > 16) {
            throw new RuntimeException('Configure separate affected Panel queue, PHP-FPM and scheduler systemd units; exclude the management worker.');
        }
        foreach ($units as $unit) {
            if (!is_string($unit) || strlen($unit) > 160 || !preg_match('/^[A-Za-z][A-Za-z0-9_.@:\-]*\.service$/D', $unit) || str_contains(strtolower(str_replace(['-', '_', '.'], '', $unit)), 'addonmanager')) {
                throw new RuntimeException('Invalid or management-worker systemd unit.');
            }
        }
        if (count(array_unique($units)) !== count($units)) {
            throw new RuntimeException('Systemd unit names must be unique.');
        }
        $this->units = $units;
    }

    private function doctorSystemd(): array
    {
        $checks = [];
        foreach ($this->units as $unit) {
            try {
                $state = $this->systemdState($unit);
                $this->assertSystemdPolicy($state, $unit);
                if (!$this->systemdRunning($state)) {
                    throw new RuntimeException('Affected systemd unit must be active and running: ' . $unit);
                }
                foreach (['start', 'stop'] as $verb) {
                    $command = [$this->binary, '--system', $verb, '--', $unit];
                    $permission = $this->execute(array_merge(['/usr/bin/sudo', '-n', '-l', '-u', 'root', '--'], $command));
                    if ($permission['exit'] !== 0) {
                        throw new RuntimeException('Grant narrowly scoped passwordless permission for systemctl --system ' . $verb . ' -- ' . $unit . '.');
                    }
                }
                $checks[] = ['unit' => $unit, 'passed' => true, 'message' => 'Systemd unit is running with process-group shutdown and scoped start/stop permission.'];
            } catch (RuntimeException $error) {
                $checks[] = ['unit' => $unit, 'passed' => false, 'message' => $error->getMessage()];
            }
        }
        return ['ready' => !in_array(false, array_column($checks, 'passed'), true), 'driver' => 'systemd', 'checks' => $checks];
    }

    private function stopSystemd(): array
    {
        $stopped = [];
        foreach ($this->units as $unit) {
            $state = $this->systemdState($unit);
            $this->assertSystemdPolicy($state, $unit);
            if (!$this->systemdStopped($state)) {
                $this->systemdControl('stop', $unit);
                $state = $this->systemdState($unit);
                if (!$this->systemdStopped($state)) {
                    // Do not restart earlier units: activation/recovery must remain quiescent.
                    throw new RuntimeException('Affected systemd unit has not quiesced: ' . $unit . '; keep maintenance and stopped services until recovery.');
                }
            }
            $stopped[] = $unit;
        }
        return ['stopped' => $stopped];
    }

    private function startSystemd(): array
    {
        $started = [];
        try {
            foreach (array_reverse($this->units) as $unit) {
                $this->assertSystemdPolicy($this->systemdState($unit), $unit);
                $this->systemdControl('start', $unit);
                if (!$this->systemdRunning($this->systemdState($unit))) {
                    throw new RuntimeException('Systemd could not start affected Panel unit ' . $unit . '; keep maintenance until service recovery.');
                }
                $started[] = $unit;
            }
        } catch (RuntimeException $error) {
            $this->stopSystemd();
            throw $error;
        }
        return ['started' => $started];
    }

    private function systemdState(string $unit): array
    {
        $properties = ['Id', 'LoadState', 'ActiveState', 'SubState', 'MainPID', 'ControlPID', 'Job', 'KillMode', 'SendSIGKILL', 'CanStart', 'CanStop'];
        $response = $this->execute([$this->binary, '--system', '--no-pager', '--all', 'show', '--property=' . implode(',', $properties), '--', $unit]);
        $state = [];
        foreach (preg_split('/\r?\n/', trim($response['output'])) as $line) {
            if (str_contains($line, '=')) {
                [$key, $value] = explode('=', $line, 2);
                if (array_key_exists($key, $state)) {
                    throw new RuntimeException('Duplicate systemd state field for ' . $unit . '.');
                }
                $state[$key] = $value;
            }
        }
        if ($response['exit'] !== 0 || array_diff($properties, array_keys($state)) !== [] || $state['Id'] !== $unit || $state['LoadState'] !== 'loaded' || !ctype_digit($state['MainPID']) || !ctype_digit($state['ControlPID'])) {
            throw new RuntimeException('Cannot read a loaded systemd unit with complete process state: ' . $unit . '.');
        }
        return $state;
    }

    private function assertSystemdPolicy(array $state, string $unit): void
    {
        if ($state['KillMode'] !== 'control-group' || $state['SendSIGKILL'] !== 'yes' || $state['CanStart'] !== 'yes' || $state['CanStop'] !== 'yes') {
            throw new RuntimeException('Systemd unit requires KillMode=control-group, SendSIGKILL=yes and start/stop support: ' . $unit . '.');
        }
    }

    private function systemdNoJob(array $state): bool
    {
        return preg_match('/^(?:|0(?:\s+\/|\/)?)$/D', trim($state['Job'])) === 1;
    }

    private function systemdRunning(array $state): bool
    {
        return $state['ActiveState'] === 'active' && $state['SubState'] === 'running' && (int) $state['MainPID'] > 0 && (int) $state['ControlPID'] === 0 && $this->systemdNoJob($state);
    }

    private function systemdStopped(array $state): bool
    {
        return $state['ActiveState'] === 'inactive' && $state['SubState'] === 'dead' && (int) $state['MainPID'] === 0 && (int) $state['ControlPID'] === 0 && $this->systemdNoJob($state);
    }

    private function systemdControl(string $verb, string $unit): void
    {
        $response = $this->execute(['/usr/bin/sudo', '-n', '-u', 'root', '--', $this->binary, '--system', $verb, '--', $unit]);
        if ($response['exit'] !== 0) {
            throw new RuntimeException('Systemd ' . $verb . ' failed for ' . $unit . '; keep maintenance until service recovery.');
        }
    }

    private function states(string $output): array
    {
        $states = [];
        foreach (preg_split('/\r?\n/', trim($output)) as $line) {
            if (preg_match('/^[A-Za-z0-9_:\-]+\s+(STOPPED|STARTING|RUNNING|BACKOFF|STOPPING|EXITED|FATAL|UNKNOWN)\b/', $line, $match)) {
                $states[] = $match[1];
            }
        }
        return $states;
    }

    private function run(string $verb, string $group): array
    {
        return $this->execute([$this->binary, $verb, $group . ':*']);
    }

    private function execute(array $command): array
    {
        $process = proc_open($command, [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
        if (!is_resource($process)) {
            throw new RuntimeException('Cannot execute supervised Panel service control.');
        }
        fclose($pipes[0]);
        stream_set_blocking($pipes[1], false);
        stream_set_blocking($pipes[2], false);
        $deadline = microtime(true) + $this->timeout;
        $output = '';
        $diagnosticBytes = 0;
        try {
            do {
                $output .= stream_get_contents($pipes[1], 65536);
                $diagnosticBytes += strlen(stream_get_contents($pipes[2], 65536));
                $status = proc_get_status($process);
                if (strlen($output) + $diagnosticBytes > 65536) {
                    throw new RuntimeException('Supervised service control exceeded its output limit.');
                }
                if (!$status['running']) {
                    break;
                }
                if (microtime(true) > $deadline) {
                    throw new RuntimeException($this->driver === 'systemd'
                        ? 'Systemd service control timed out. Verify unit timeouts and scoped permission; keep maintenance until recovery.'
                        : 'Supervised service control timed out. Verify stopwaitsecs and scoped permission.');
                }
                usleep(20000);
            } while (true);
            $output .= stream_get_contents($pipes[1], 65536);
            $diagnosticBytes += strlen(stream_get_contents($pipes[2], 65536));
            if (strlen($output) + $diagnosticBytes > 65536) {
                throw new RuntimeException('Supervised service control exceeded its output limit.');
            }
            fclose($pipes[1]);
            fclose($pipes[2]);
            $exit = proc_close($process);
            $process = null;
            return ['exit' => $exit === -1 ? ($status['exitcode'] ?? -1) : $exit, 'output' => $output];
        } finally {
            if (is_resource($process)) {
                $status = proc_get_status($process);
                if ($status['running']) {
                    proc_terminate($process);
                    $killDeadline = microtime(true) + 1;
                    do {
                        stream_get_contents($pipes[1], 65536);
                        stream_get_contents($pipes[2], 65536);
                        $status = proc_get_status($process);
                        if (!$status['running']) break;
                        usleep(20000);
                    } while (microtime(true) < $killDeadline);
                    if ($status['running']) proc_terminate($process, 9);
                }
                foreach ($pipes as $pipe) {
                    if (is_resource($pipe)) fclose($pipe);
                }
                proc_close($process);
            }
        }
    }
}
